from pydub import AudioSegment
import asyncio
import shazamio
import os

async def split_audio(file_path, duration):
    # Charger le fichier audio
    audio = AudioSegment.from_file(file_path)

    # Durée totale du fichier audio en millisecondes
    total_duration = len(audio)

    segments_info = []

    # Découper le fichier audio en segments de durée fixe
    for i in range(0, total_duration, duration * 1000):
        start_time = i / 1000  # Conversion de millisecondes en secondes
        end_time = min((i + duration * 1000) / 1000, total_duration / 1000)  # Éviter de dépasser la durée totale
        segment = audio[i:i + duration * 1000]

        # Stocker les informations du segment
        segments_info.append((start_time, end_time, segment))

    return segments_info
    
async def detect_music(segment):
    # Initialiser le client Shazam
    shazam = shazamio.Shazam()

    results = []

    # Analyser le segment avec Shazam
    matches = await shazam.recognize(segment)

    # Vérifier si une correspondance a été trouvée
    if 'track' in matches and 'title' in matches['track'] and 'subtitle' in matches['track']:
        music_detected = True
        music_name = matches['track']['title']
        artist_name = matches['track']['subtitle']
    else:
        music_detected = False
        music_name = None
        artist_name = None

    results.append([music_detected, music_name, artist_name])

    return results

async def extract_music_info(file_path, results):
    with open(file_path, 'w') as file:
        _, last_music, last_artist = results[0]
        i = 0
        detected_music = set()
        for result in results:
            if result[0] and (last_music, last_artist) != (result[1], result[2]) and (result[1], result[2]) not in detected_music:
                truc = f"{i+1}- {last_music} - {last_artist}\n"
                file.write(truc)
                i += 1
                last_music, last_artist = result[1], result[2]
                detected_music.add((last_music, last_artist))
        if (last_music, last_artist) not in detected_music:
            truc = f"{i+1}- {last_music} - {last_artist}\n"
            file.write(truc)

async def main():
    # Chemin vers le fichier audio
    file_path = "C:/Users/Martin/Documents/ISEN/M1/M1_Projet_2023_2024/S2/ukf_cut.mp3"

    # Extraire le nom du fichier sans extension
    file_name = os.path.splitext(os.path.basename(file_path))[0]

    # Durée de chaque segment en secondes
    segment_duration = 10

    # Découper le fichier audio en segments
    segments_info = await split_audio(file_path, segment_duration)

    music_results = []

    # Afficher les informations sur chaque segment
    for i, (start_time, end_time, segment) in enumerate(segments_info):
        print(f"Segment {i+1}: Début={start_time} secondes, Fin={end_time} secondes")
        
        # Exporter le segment audio combiné au format WAV (sans réencodage)
        output_file = f"{file_name}_segment.mp3"
        segment.export(output_file, format="mp3")
        print("Segments combinés exportés avec succès.")
        results = await detect_music(output_file)
        print("Résultats de la détection de musique : ", results)

        music_results.extend(results)

    # Écrire les résultats dans un fichier texte avec le nom du fichier audio
    output_file_name = f"{file_name}_results_V7_{int(segment_duration)}.txt"
    await extract_music_info(output_file_name, music_results)

# Lancer l'exécution du programme principal
asyncio.run(main())
