import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np

# Charger le fichier audio
audio_path = 'C:/Users/Martin/Music/test.mp3'
y, sr = librosa.load(audio_path)

# Afficher le spectrogramme
plt.figure(figsize=(12, 6))
librosa.display.specshow(librosa.amplitude_to_db(librosa.stft(y), ref=np.max), sr=sr, x_axis='time', y_axis='log')
plt.colorbar(format='%+2.0f dB')
plt.title('Spectrogramme')
plt.show()

# Jouer le fichier audio
import IPython.display as ipd
ipd.Audio(audio_path)

# Paramètres de segmentation
frame_length = 2048
hop_length = 512

# Calcul de l'énergie par trame
energy = librosa.feature.rms(y=y, frame_length=frame_length, hop_length=hop_length)[0]

# Seuil d'énergie pour la détection de silence
energy_threshold = np.mean(energy) * 0.5

# Détection de silence
silence_indices = np.where(energy < energy_threshold)[0]

# Diviser les segments en fonction du silence
segments = []
start_index = 0
for end_index in silence_indices:
    segment = (start_index * hop_length, end_index * hop_length)
    segments.append(segment)
    start_index = end_index + 1

# Afficher les segments détectés
for i, segment in enumerate(segments):
    print(f"Segment {i+1}: Début - {segment[0]/sr} sec, Fin - {segment[1]/sr} sec")

