from pydub import AudioSegment
import asyncio
import shazamio

async def split_audio(file_path, duration):
    # Charger le fichier audio
    audio = AudioSegment.from_file(file_path)

    # Durée totale du fichier audio en millisecondes
    total_duration = len(audio)

    segments_info = []

    # Découper le fichier audio en segments de durée fixe
    for i in range(0, total_duration, duration * 1000):
        start_time = i / 1000  # Conversion de millisecondes en secondes
        end_time = min((i + duration * 1000) / 1000, total_duration / 1000)  # Éviter de dépasser la durée totale
        segment = audio[i:i + duration * 1000]

        # Stocker les informations du segment
        segments_info.append((start_time, end_time, segment))

    return segments_info
    
async def detect_music(segment):
    # Initialiser le client Shazam
    shazam = shazamio.Shazam()

    results = []

    # Analyser le segment avec Shazam
    matches = await shazam.recognize(segment)

    # Vérifier si une correspondance a été trouvée
    if 'track' in matches and 'title' in matches['track'] and 'subtitle' in matches['track']:
        music_detected = True
        music_name = matches['track']['title']
        artist_name = matches['track']['subtitle']
    else:
        music_detected = False
        music_name = None
        artist_name = None

    results.append([music_detected, music_name, artist_name])

    return results

async def main():
    # Chemin vers le fichier audio
    file_path = "C:/Users/Martin/Documents/ISEN/M1/M1_Projet_2023_2024/S2/set.wav"

    # Durée de chaque segment en secondes
    segment_duration = 10

    # Découper le fichier audio en segments
    segments_info = await split_audio(file_path, segment_duration)

    # Afficher les informations sur chaque segment
    for i, (start_time, end_time, _) in enumerate(segments_info):
        segment_duration = end_time - start_time
        print(f"Segment {i+1}: Début={start_time} secondes, Fin={end_time} secondes, Durée={segment_duration} secondes")

    # Extrait les segments 26 et 27
    segment_26 = segments_info[25][2]
    segment_27 = segments_info[26][2]

    # Combine les deux segments en un seul
    combined_segment = segment_26 + segment_27

    # Exporter le segment audio combiné au format WAV (sans réencodage)
    output_file = "segment_combined.wav"
    combined_segment.export(output_file, format="wav")
    print("Segments combinés exportés avec succès.")

    # Détecter la musique dans le segment combiné
    print("Musique reconnue:", await detect_music('segment_combined.wav'))

# Lancer l'exécution du programme principal
asyncio.run(main())
