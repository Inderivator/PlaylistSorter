import librosa
import shazamio
import numpy as np
from pydub import AudioSegment

def split_audio(file_path, duration):
    # Charger le fichier audio
    y, sr = librosa.load(file_path)

    # Calculer le nombre total de segments
    total_segments = int(len(y) / (sr * duration))

    segments_info = []

    for i in range(total_segments):
        # Calculer le début et la fin de chaque segment
        start_time = i * duration
        end_time = (i + 1) * duration

        # Découper le segment audio
        segment = y[start_time * sr: end_time * sr]

        # Stocker les informations du segment
        segments_info.append((start_time, end_time, segment, sr))

    return segments_info

# def detect_music(segments_info):
#     # Initialiser le client Shazam
#     shazam = shazamio.Shazam()

#     results = []

#     for start_time, end_time, segment in segments_info:
#         # Analyser le segment avec Shazam
#         matches = shazam.identify_song(segment, sr)

#         # Vérifier si une correspondance a été trouvée
#         if matches:
#             match = matches[0]  # Prendre la première correspondance
#             music_detected = True
#             music_name = match['track']['title']
#         else:
#             music_detected = False
#             music_name = None

#         results.append([start_time, end_time, music_detected, music_name])

#     return results

# Chemin vers le fichier audio
file_path = "C:/Users/Martin/Documents/ISEN/M1/M1_Projet_2023_2024/S2/set.wav"

# Durée de chaque segment en secondes
segment_duration = 10

# Découper le fichier audio en segments
segments_info = split_audio(file_path, segment_duration)

# Afficher les informations sur chaque segment
for i, (start_time, end_time, _, sr) in enumerate(segments_info):
    segment_duration = end_time - start_time
    print(f"Segment {i+1}: Début={start_time} secondes, Fin={end_time} secondes, Durée={segment_duration} secondes, sr={sr}")

# Récupérer les segments audio 25 et 26
segment_index_25 = 25
segment_index_26 = 26
segment_25 = segments_info[segment_index_25][2]
segment_26 = segments_info[segment_index_26][2]
sr = segments_info[segment_index_25][3]

# Combiner les segments audio
combined_segment = segment_25 + segment_26

# Convertir le segment combiné en un objet AudioSegment de pydub
audio_segment = AudioSegment(
    combined_segment.tobytes(),
    frame_rate=sr,  # Utiliser le taux d'échantillonnage du fichier audio original
    sample_width=combined_segment.dtype.itemsize,
    channels=1  # Assumption: Le fichier audio est mono
)

# Exporter le segment audio au format WAV (sans réencodage)
output_file = "sample_segment.wav"
audio_segment.export(output_file, format="wav")
print("Segment combiné exporté avec succès.")

# # Détecter la musique dans chaque segment
# results = detect_music(segments_info)

# # Afficher les résultats
# for result in results:
#     print(result)
