from pydub import AudioSegment

# Chemin vers le fichier audio
file_path = "C:/Users/Martin/Documents/ISEN/M1/M1_Projet_2023_2024/S2/set.mp3"

# Charger le fichier audio
audio = AudioSegment.from_file(file_path)

# Durée de chaque segment en millisecondes
segment_duration = 150 * 1000  # Convertir en millisecondes

# Extraire le segment 25
start_time_25 = 0 * segment_duration
end_time_25 = (0 + 1) * segment_duration
segment_25 = audio[start_time_25:end_time_25]

# Extraire le segment 26
start_time_26 = 1 * segment_duration
end_time_26 = (1 + 1) * segment_duration
segment_26 = audio[start_time_26:end_time_26]

# Combiner les segments 25 et 26
combined_segment = segment_25 + segment_26

# Exporter le segment audio combiné au format WAV (sans réencodage)
output_file = "combined_segments.mp3"
combined_segment.export(output_file, format="mp3")

print("Segment combiné exporté avec succès.")
