import asyncio
from shazamio import Shazam

async def main():
  shazam = Shazam()
  results = []
  # out = await shazam.recognize_song('dora.ogg') # slow and deprecated, don't use this!
  matches = await shazam.recognize('players.mp3')  # rust version, use this!
  # Vérifiez si la réponse contient des informations sur la musique
  if 'track' in matches and 'title' in matches['track'] and 'subtitle' in matches['track']:
      music_detected = True
      music_name = matches['track']['title']
      artist_name = matches['track']['subtitle']
      
      track_info = {
          'title': matches['track']['title'],
          'artist': matches['track']['subtitle']
      }
      print("Musique reconnue :")
      print("---------------")
      print("| Titre             | Artiste           |")
      print("---------------")
      print(f"| {track_info['title']:<18} | {track_info['artist']:<18} |")
      print("---------------")
  else:
      music_detected = False
      music_name = None
      artist_name = None
      print("Aucune information sur la musique trouvée.")
  
  results.append([music_detected, music_name, artist_name])

  print(results)

loop = asyncio.get_event_loop()
loop.run_until_complete(main())
